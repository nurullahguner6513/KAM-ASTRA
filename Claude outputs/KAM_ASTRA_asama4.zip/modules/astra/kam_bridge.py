"""
KAM ↔ ASTRA köprüsü.

main.py yalnızca bu dosyayı kullanır:
  - ASTRA_TOOL_DECLARATIONS : Gemini'ye eklenen sağlık araçları
  - start_astra(ui, kam)     : köprüyü kurar ve arka plan izlemesini başlatır
  - AstraBridge.handle_tool  : Gemini araç çağrısını yanıtlar
  - AstraBridge.handle_text  : "astra ..." ile başlayan yazılı komutları yerel olarak yanıtlar
  - astra_is_speaking        : ASTRA konuşurken mikrofonun Gemini'ye gönderilmemesi için

Gizlilik kararı (AŞAMA 3): Sağlık değerleri Gemini'ye gönderilmez. Araçlar Gemini'ye
yalnızca "sonuç yerel olarak okunuyor" der; rapor ekranda gösterilir ve Windows'un
yerleşik sesiyle okunur. İzleme ve sesli uyarılar kendi iş parçacığında çalışır;
internet veya Gemini bağlantısı kesilse de sürer.
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Callable

from . import display, get_astra_logger
from .alert_manager import LEVEL_NAMES
from .astra_core import AstraCore
from .health_analyzer import INDICATORS
from .health_database import HealthDatabase
from .models import utc_now
from .radiation.radiation_analyzer import assess_radiation
from .risk_engine import RiskAssessment, day_start
from .simulation.live_feed import LiveSimulationFeed
from .simulation.mission_scenarios import SCENARIOS
from .voice import health_voice
from .voice.voice_alerts import VoiceAlerts, astra_is_speaking, find_turkish_voice, windows_speaker

SETTINGS_PATH = Path(__file__).resolve().parent / "config" / "astra_settings.json"
DEFAULT_SETTINGS = {
    "enabled": True,
    "mode": "simulation",          # "simulation" veya "device" (gerçek cihaz verisi)
    "astronaut": "SIM Astronot",
    "scenario": "normal",          # canlı simülasyonun bugünkü senaryosu
    "history_days": 60,            # ilk açılışta üretilecek geçmiş simülasyon günü
    "check_interval_seconds": 60,  # risk değerlendirme aralığı
    "notify_interval_seconds": 15, # uyarı kuyruğu kontrol aralığı
    "voice": "",                   # boşsa yüklü Türkçe Windows sesi aranır
    "mute_non_critical": False,    # True: seviye 1–2 sesli okunmaz (kritikler her zaman okunur)
}

GEMINI_REPLY = ("ASTRA sonucu kullanıcıya yerel olarak sesli okunuyor ve ekranda gösteriliyor. "
                "Gizlilik gereği sağlık verisi bu yanıtta paylaşılmaz. Kullanıcıya yalnızca kısaca "
                "'ASTRA raporunu okuyor' de; değer tahmin etme, yorum veya teşhis ekleme.")

ASTRA_TOOL_DECLARATIONS = [
    {
        "name": "astra_health_status",
        "description": (
            "KAM ASTRA sağlık modülü. Astronotun sağlık durumunu kayıtlı ölçümlere ve kural tabanlı risk "
            "motoruna göre değerlendirir; sonucu kendisi yerel olarak sesli okur ve ekranda gösterir. "
            "Kullanıcı sağlık durumunu, kalp atışı, HRV, oksijen, uyku, aktivite veya stres durumunu, "
            "ya da son 7 / 30 gündeki değişimlerini sorduğunda çağır."),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "period": {"type": "STRING",
                           "description": "today (bugün) | week (son 7 gün) | month (son 30 gün)"}
            },
            "required": ["period"],
        },
    },
    {
        "name": "astra_radiation_status",
        "description": ("KAM ASTRA radyasyon durumu: dozimetreden gelen günlük ve görev boyunca biriken dozu "
                        "yerel olarak sesli okur. Kullanıcı radyasyon durumunu sorduğunda çağır."),
        "parameters": {"type": "OBJECT", "properties": {}},
    },
    {
        "name": "astra_alerts",
        "description": ("KAM ASTRA sağlık uyarıları. action=list bekleyen uyarıları okur; action=acknowledge "
                        "kullanıcı uyarıyı aldığını söylediğinde ('tamam', 'uyarıyı onayla', 'anladım') "
                        "bekleyen tüm sağlık uyarılarını onaylar."),
        "parameters": {
            "type": "OBJECT",
            "properties": {"action": {"type": "STRING", "description": "list | acknowledge"}},
            "required": ["action"],
        },
    },
    {
        "name": "astra_simulation",
        "description": ("KAM ASTRA simülasyon senaryosunu değiştirir (yalnızca test amaçlı simülasyon verisi). "
                        "Senaryolar: " + ", ".join(SCENARIOS) + "."),
        "parameters": {
            "type": "OBJECT",
            "properties": {"scenario": {"type": "STRING", "description": "senaryo adı"}},
            "required": ["scenario"],
        },
    },
]

_TEXT_HELP = ("ASTRA komutları: 'astra durum', 'astra hafta', 'astra ay', 'astra radyasyon', "
              "'astra uyarılar', 'astra onay', 'astra senaryo <ad>', 'astra senaryolar'.")


def load_settings(path: Path = SETTINGS_PATH) -> dict:
    settings = dict(DEFAULT_SETTINGS)
    try:
        if path.exists():
            settings.update(json.loads(path.read_text(encoding="utf-8")))
    except Exception as exc:
        get_astra_logger().warning("astra_settings.json okunamadı, varsayılanlar kullanılıyor: %s", exc)
    return settings


def _normalize(text: str) -> str:
    text = (text or "").replace("İ", "i").replace("I", "ı").lower()
    for a, b in (("ı", "i"), ("ğ", "g"), ("ü", "u"), ("ş", "s"), ("ö", "o"), ("ç", "c")):
        text = text.replace(a, b)
    return " ".join(text.split())


class AstraBridge:
    def __init__(self, ui=None, kam=None, settings: dict | None = None, db: HealthDatabase | None = None,
                 speaker: Callable[[str], None] | None = None, clock: Callable[[], datetime] = utc_now,
                 synchronous_voice: bool = False):
        self.settings = {**load_settings(), **(settings or {})}
        self.ui = ui
        self.kam = kam
        self.clock = clock
        self.simulated = self.settings["mode"] != "device"
        self.db = db or HealthDatabase()
        self.core = AstraCore(self.db, self.simulated)
        self.astronaut_id = self.db.add_astronaut(self.settings["astronaut"])
        self.feed = (LiveSimulationFeed(self.db, self.astronaut_id, self.settings["scenario"],
                                        int(self.settings["history_days"])) if self.simulated else None)
        self._log = get_astra_logger()
        if speaker is None:
            voice = self.settings["voice"] or find_turkish_voice() or ""
            if not voice:
                self._ui_log("ASTRA: Türkçe Windows sesi bulunamadı; uyarılar varsayılan Windows sesiyle okunacak.")
            speaker = windows_speaker(voice)
        self.voice = VoiceAlerts(speaker, self._kam_busy, synchronous=synchronous_voice)
        self._lock = threading.RLock()
        self._last_eval: datetime | None = None
        self._current_day: datetime | None = None
        self.last_assessment: RiskAssessment | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    # ── KAM / arayüz yardımcıları ────────────────────────────────────────
    def _kam_busy(self) -> bool:
        return bool(getattr(self.kam, "_is_speaking", False))

    def _ui_call(self, method: str, *args) -> None:
        fn = getattr(self.ui, method, None)
        if fn is None:
            return
        try:
            fn(*args)
        except Exception as exc:
            self._log.warning("ASTRA arayüz çağrısı başarısız (%s): %s", method, exc)

    def _ui_log(self, text: str) -> None:
        self._ui_call("write_log", text)

    def _show(self, title: str, text: str) -> None:
        self._ui_call("show_health_hologram", title, text)

    def _respond(self, panel_text: str, spoken: str, level: int = 1, delay: float = 0.0) -> None:
        """Paneli günceller, yanıtı sohbet günlüğüne yazar ve yerel olarak seslendirir."""
        self._show("astra", panel_text)
        self._ui_log("ASTRA: " + spoken)
        self.voice.say(spoken, level, delay)

    # ── Arka plan izleme ─────────────────────────────────────────────────
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, name="ASTRA-monitor", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        mode = "SİMÜLASYON" if self.simulated else "CİHAZ"
        self._ui_log(f"ASTRA: Sağlık izleme başladı ({mode} verisi).")
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception as exc:  # izleme asla KAM'ı düşürmemeli
                self._log.exception("ASTRA izleme hatası: %s", exc)
            self._stop.wait(float(self.settings["notify_interval_seconds"]))

    def tick(self, now: datetime | None = None) -> RiskAssessment | None:
        now = now or self.clock()
        with self._lock:
            interval = float(self.settings["check_interval_seconds"])
            if self._last_eval is None or (now - self._last_eval).total_seconds() >= interval:
                if self.feed:
                    self.feed.update(now)
                today = day_start(now)
                if self._current_day is not None and self._current_day < today:
                    self.core.evaluate(self.astronaut_id, self._current_day, now=now,
                                       force_report=True)  # biten günün son raporu
                self._current_day = today
                self.last_assessment = self.core.evaluate(self.astronaut_id, today, now=now, live=True)
                self._last_eval = now
                self._update_card(self.last_assessment)
            paused = bool(getattr(self.kam, "_paused", False))
            self.core.alerts.muted = bool(self.settings["mute_non_critical"]) or paused
            for alert in self.core.alerts.due_notifications(self.astronaut_id, now):
                self._announce(alert)
            return self.last_assessment

    def _announce(self, alert: dict) -> None:
        level = alert["level"]
        text = alert["message"]
        if level >= 3:
            text += " Uyarıyı aldığında KAM'a uyarıları onayla de."
        if alert["notify_count"] > 1:
            text = "Onaylanmamış uyarı tekrarı. " + text
        self._ui_log(f"ASTRA [{LEVEL_NAMES[level]}]: {alert['message']}")
        if level >= 2:
            self._show("astra", display.alert_lines([alert]))
            self._ui_call("focus_panel", "health", 8000)
        if level >= 3:
            self._ui_call("play_error_sfx")
        if level >= 2 or alert["category"] != "data":
            self.voice.say(health_voice.to_speech(text), level)

    def _update_card(self, a: RiskAssessment) -> None:
        """Arayüzdeki 'SAĞLIK ÖZETİ' kartı (en fazla 5 satır)."""
        if self.ui is None:
            return
        v = a.summary.values
        tag = "SİM · " if a.is_simulated else ""
        lines = [f"{tag}Seviye {a.level} · {LEVEL_NAMES[a.level]}"]
        if "resting_hr" in v or "heart_rate_mean" in v:
            parts = []
            if "resting_hr" in v:
                parts.append(f"Dinlenik {v['resting_hr']:.0f}")
            if "heart_rate_mean" in v:
                parts.append(f"Ort. {v['heart_rate_mean']:.0f} bpm")
            lines.append("Nabız " + " · ".join(parts))
        if "hrv_rmssd" in v or "spo2_mean" in v:
            lines.append(" · ".join(x for x in (
                f"HRV {v['hrv_rmssd']:.0f} ms" if "hrv_rmssd" in v else "",
                f"SpO2 %{v['spo2_mean']:.0f}" if "spo2_mean" in v else "") if x))
        if "sleep_total_min" in v:
            total = int(v["sleep_total_min"])
            lines.append(f"Uyku {total // 60} sa {total % 60} dk")
        if a.radiation.has_data:
            lines.append(f"Radyasyon: görev sınırının %{a.radiation.pct_of_mission_limit:.0f}")
        if len(lines) == 1:
            lines.append("Bugün için sağlık verisi yok")
        try:
            self.ui._health_card_lines = lines[:5]
        except Exception:
            pass

    # ── Yanıtlar ─────────────────────────────────────────────────────────
    def _health(self, period: str, now: datetime, delay: float) -> None:
        with self._lock:
            if self.feed:
                self.feed.update(now)
            if period in ("week", "month"):
                days = 7 if period == "week" else 30
                thresholds = {k: v["pct_info"] for k, v in self.core.engine.config["indicators"].items()}
                comparison = self.core.engine.analyzer.period_comparison(self.astronaut_id, now, days)
                spoken = health_voice.spoken_period(comparison, days, self.simulated, thresholds)
                self._respond(display.period_lines(comparison, days, self.simulated), spoken, delay=delay)
            else:
                a = self.core.engine.assess(self.astronaut_id, now, now)
                self._respond(display.daily_lines(a), health_voice.spoken_daily(a), max(a.level, 1), delay)
        self.db.log_access("kam", "health_status", period)

    def _radiation(self, now: datetime, delay: float) -> None:
        with self._lock:
            if self.feed:
                self.feed.update(now)
            text = self.core.radiation_report(self.astronaut_id, now)
            status = assess_radiation(self.db, self.astronaut_id, day_start(now), self.simulated,
                                      self.core.engine.config["radiation"])
        self._respond(display.radiation_lines(status, now, self.simulated), health_voice.to_speech(text),
                      max(status.level, 1), delay)
        self.db.log_access("kam", "radiation_status")

    def _alerts_list(self, delay: float) -> None:
        active = self.core.alerts.active(self.astronaut_id)
        self._respond(display.alert_lines(active), health_voice.spoken_alerts(active), delay=delay)

    def acknowledge_all(self, now: datetime) -> int:
        count = sum(self.core.alerts.acknowledge(a["id"], now) for a in self.core.alerts.active(self.astronaut_id))
        self._ui_log(f"ASTRA: {count} sağlık uyarısı onaylandı.")
        self.db.log_access("kam", "acknowledge_alerts", str(count))
        return count

    def set_scenario(self, scenario: str, now: datetime) -> str:
        if not self.feed:
            return "ASTRA gerçek cihaz kipinde; simülasyon senaryosu değiştirilemez."
        if scenario not in SCENARIOS:
            return "Bilinmeyen senaryo. Senaryolar: " + ", ".join(SCENARIOS) + "."
        with self._lock:
            self.feed.set_scenario(scenario, now)
            self._last_eval = None  # sonraki turda hemen değerlendir
        message = f"Simülasyon senaryosu '{scenario}' ({SCENARIOS[scenario].description}) olarak ayarlandı."
        self._ui_log("ASTRA: " + message)
        return message

    def handle_tool(self, name: str, args: dict) -> str:
        """Gemini araç çağrısı. Dönen metin Gemini'ye gider; sağlık verisi içermez."""
        now = self.clock()
        delay = 1.5  # Gemini'nin kısa cevabının başlaması için
        try:
            if name == "astra_health_status":
                period = str(args.get("period", "today")).lower()
                self._health(period if period in ("week", "month") else "today", now, delay)
                return GEMINI_REPLY
            if name == "astra_radiation_status":
                self._radiation(now, delay)
                return GEMINI_REPLY
            if name == "astra_alerts":
                if str(args.get("action", "list")).lower().startswith("ack"):
                    return f"{self.acknowledge_all(now)} sağlık uyarısı onaylandı."
                self._alerts_list(delay)
                return GEMINI_REPLY
            if name == "astra_simulation":
                return self.set_scenario(str(args.get("scenario", "")).strip(), now)
            return f"Bilinmeyen ASTRA aracı: {name}"
        except Exception as exc:
            self._log.exception("ASTRA araç hatası (%s): %s", name, exc)
            return f"ASTRA hatası: {exc}"

    def handle_text(self, text: str) -> bool:
        """'astra' ile başlayan yazılı komutları Gemini'ye göndermeden yanıtlar (çevrimdışı çalışır)."""
        words = _normalize(text).split()
        if not words or words[0] != "astra":
            return False
        command = words[1] if len(words) > 1 else "durum"
        now = self.clock()
        try:
            if command in ("durum", "saglik", "bugun"):
                self._health("today", now, 0)
            elif command == "hafta":
                self._health("week", now, 0)
            elif command == "ay":
                self._health("month", now, 0)
            elif command == "radyasyon":
                self._radiation(now, 0)
            elif command.startswith("uyari"):
                self._alerts_list(0)
            elif command.startswith("onay"):
                count = self.acknowledge_all(now)
                self.voice.say(f"{count} uyarı onaylandı.", 1)
            elif command == "senaryolar":
                self._ui_log("ASTRA senaryoları: " + ", ".join(SCENARIOS))
            elif command == "senaryo" and len(words) > 2:
                self._ui_log("ASTRA: " + self.set_scenario(words[2], now))
            else:
                self._ui_log(_TEXT_HELP)
        except Exception as exc:
            self._log.exception("ASTRA komut hatası: %s", exc)
            self._ui_log(f"ERR: ASTRA komutu çalışmadı — {exc}")
        return True


def start_astra(ui, kam) -> AstraBridge | None:
    """KAM açılırken çağrılır. Hata olursa None döner ve KAM ASTRA'sız çalışmaya devam eder."""
    try:
        settings = load_settings()
        if not settings.get("enabled", True):
            return None
        bridge = AstraBridge(ui, kam, settings)
        bridge.start()
        return bridge
    except Exception as exc:
        get_astra_logger().exception("ASTRA başlatılamadı: %s", exc)
        try:
            ui.write_log(f"ERR: ASTRA sağlık modülü başlatılamadı — {exc}")
        except Exception:
            pass
        return None


__all__ = ["ASTRA_TOOL_DECLARATIONS", "AstraBridge", "astra_is_speaking", "start_astra"]
